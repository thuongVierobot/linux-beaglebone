#include <../lib/fdtdec_common.c>
