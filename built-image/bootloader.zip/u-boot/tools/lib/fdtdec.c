#include <../lib/fdtdec.c>
