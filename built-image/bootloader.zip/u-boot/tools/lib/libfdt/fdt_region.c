#include <../lib/libfdt/fdt_region.c>
