#include <../lib/libfdt/fdt_ro.c>
