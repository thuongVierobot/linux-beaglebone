#include <../common/image-fit.c>
