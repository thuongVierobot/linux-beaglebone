// SPDX-License-Identifier: GPL-2.0+
/*
 * Copyright (c) 2016 Andreas Färber
 */

#include <common.h>

int board_init(void)
{
	return 0;
}
