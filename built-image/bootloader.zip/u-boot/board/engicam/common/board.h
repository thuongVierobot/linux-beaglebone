/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2016 Amarula Solutions B.V.
 */

#ifndef _BOARD_H_
#define _BOARD_H_
void setup_gpmi_nand(void);
void setup_display(void);
#endif /* _BOARD_H_ */
